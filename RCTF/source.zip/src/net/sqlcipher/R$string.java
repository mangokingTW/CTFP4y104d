// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.sqlcipher;


// Referenced classes of package net.sqlcipher:
//            R

public static final class 
{

    public static final int app_name = 0x7f040001;
    public static final int hello = 0x7f040000;

    public ()
    {
    }
}
