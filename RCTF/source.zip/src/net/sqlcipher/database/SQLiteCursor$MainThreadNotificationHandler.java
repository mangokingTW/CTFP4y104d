// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.sqlcipher.database;

import android.os.Handler;
import android.os.Message;

// Referenced classes of package net.sqlcipher.database:
//            SQLiteCursor

protected class this._cls0 extends Handler
{

    final SQLiteCursor this$0;

    public void handleMessage(Message message)
    {
        SQLiteCursor.access$700(SQLiteCursor.this);
    }

    protected ()
    {
        this$0 = SQLiteCursor.this;
        super();
    }
}
