// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.sqlcipher.database;

import java.util.ArrayList;

// Referenced classes of package net.sqlcipher.database:
//            SQLiteDebug

public static class 
{

    public long databaseBytes;
    public ArrayList dbStats;
    public int largestMemAlloc;
    public int memoryUsed;
    public int numPagers;
    public int pageCacheOverflo;
    public long referencedBytes;
    public long totalBytes;

    public ()
    {
    }
}
