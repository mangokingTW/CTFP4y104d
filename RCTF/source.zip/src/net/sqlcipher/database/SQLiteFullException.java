// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.sqlcipher.database;


// Referenced classes of package net.sqlcipher.database:
//            SQLiteException

public class SQLiteFullException extends SQLiteException
{

    public SQLiteFullException()
    {
    }

    public SQLiteFullException(String s)
    {
        super(s);
    }
}
