// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package net.sqlcipher;


// Referenced classes of package net.sqlcipher:
//            R

public static final class 
{

    public static final int sqllog = 0x7f050000;

    public ()
    {
    }
}
