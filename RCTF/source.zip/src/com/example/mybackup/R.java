// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.mybackup;


public final class R
{
    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class drawable
    {

        public static final int ic_launcher = 0x7f020000;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int author = 0x7f070001;
        public static final int bookname = 0x7f070000;
        public static final int bookslist = 0x7f070002;
        public static final int menu_settings = 0x7f070003;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int activity_entry = 0x7f030000;
        public static final int main = 0x7f030001;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int activity_entry = 0x7f060000;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int app_name = 0x7f040000;
        public static final int hello_world = 0x7f040001;
        public static final int menu_settings = 0x7f040002;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f050000;
        public static final int AppTheme = 0x7f050001;

        public style()
        {
        }
    }


    public R()
    {
    }
}
