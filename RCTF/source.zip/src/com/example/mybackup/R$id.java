// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.example.mybackup;


// Referenced classes of package com.example.mybackup:
//            R

public static final class 
{

    public static final int author = 0x7f070001;
    public static final int bookname = 0x7f070000;
    public static final int bookslist = 0x7f070002;
    public static final int menu_settings = 0x7f070003;

    public ()
    {
    }
}
