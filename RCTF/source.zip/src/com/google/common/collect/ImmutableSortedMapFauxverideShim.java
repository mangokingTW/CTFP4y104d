// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            ImmutableMap, ImmutableSortedMap

abstract class ImmutableSortedMapFauxverideShim extends ImmutableMap
{

    ImmutableSortedMapFauxverideShim()
    {
    }

    public static ImmutableSortedMap.Builder builder()
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedMap of(Object obj, Object obj1)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedMap of(Object obj, Object obj1, Object obj2, Object obj3)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedMap of(Object obj, Object obj1, Object obj2, Object obj3, Object obj4, Object obj5)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedMap of(Object obj, Object obj1, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, Object obj7)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedMap of(Object obj, Object obj1, Object obj2, Object obj3, Object obj4, Object obj5, Object obj6, Object obj7, 
            Object obj8, Object obj9)
    {
        throw new UnsupportedOperationException();
    }
}
