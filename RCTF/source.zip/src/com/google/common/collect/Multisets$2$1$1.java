// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package com.google.common.collect:
//            AbstractIterator, Multiset, Multisets, AbstractMultiset, 
//            Sets

class  extends AbstractIterator
{

    final computeNext this$1;
    final Iterator val$iterator1;

    protected  computeNext()
    {
        while (val$iterator1.hasNext()) 
        {
              = (val.iterator1)val$iterator1.next();
            Object obj = .etElement();
            int i = Math.min(.etCount(), multiset2.count(obj));
            if (i > 0)
            {
                return Multisets.immutableEntry(obj, i);
            }
        }
        return (bleEntry)endOfData();
    }

    protected volatile Object computeNext()
    {
        return computeNext();
    }

    ()
    {
        this$1 = final_;
        val$iterator1 = Iterator.this;
        super();
    }

    // Unreferenced inner class com/google/common/collect/Multisets$2

/* anonymous class */
    static final class Multisets._cls2 extends AbstractMultiset
    {

        final Set entrySet = new Multisets._cls2._cls1();
        final Multiset val$multiset1;
        final Multiset val$multiset2;

        public int count(Object obj)
        {
            int i = multiset1.count(obj);
            if (i == 0)
            {
                return 0;
            } else
            {
                return Math.min(i, multiset2.count(obj));
            }
        }

        Set createElementSet()
        {
            return Sets.intersection(multiset1.elementSet(), multiset2.elementSet());
        }

        public Set entrySet()
        {
            return entrySet;
        }

            
            {
                multiset1 = multiset;
                multiset2 = multiset3;
                super();
            }
    }


    // Unreferenced inner class com/google/common/collect/Multisets$2$1

/* anonymous class */
    class Multisets._cls2._cls1 extends AbstractSet
    {

        final Multisets._cls2 this$0;

        public boolean contains(Object obj)
        {
            boolean flag1 = false;
            boolean flag = flag1;
            if (obj instanceof Multiset.Entry)
            {
                obj = (Multiset.Entry)obj;
                int i = ((Multiset.Entry) (obj)).getCount();
                flag = flag1;
                if (i > 0)
                {
                    flag = flag1;
                    if (count(((Multiset.Entry) (obj)).getElement()) == i)
                    {
                        flag = true;
                    }
                }
            }
            return flag;
        }

        public boolean isEmpty()
        {
            return elementSet().isEmpty();
        }

        public Iterator iterator()
        {
            return multiset1.entrySet().iterator(). new Multisets._cls2._cls1._cls1();
        }

        public int size()
        {
            return elementSet().size();
        }

            
            {
                this$0 = Multisets._cls2.this;
                super();
            }
    }

}
