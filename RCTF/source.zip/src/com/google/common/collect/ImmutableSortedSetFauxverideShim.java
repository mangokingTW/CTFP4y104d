// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            ImmutableSet, ImmutableSortedSet

abstract class ImmutableSortedSetFauxverideShim extends ImmutableSet
{

    ImmutableSortedSetFauxverideShim()
    {
    }

    public static ImmutableSortedSet.Builder builder()
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet copyOf(Object aobj[])
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object obj)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object obj, Object obj1)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object obj, Object obj1, Object obj2)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object obj, Object obj1, Object obj2, Object obj3)
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object obj, Object obj1, Object obj2, Object obj3, Object obj4)
    {
        throw new UnsupportedOperationException();
    }

    public static transient ImmutableSortedSet of(Object obj, Object obj1, Object obj2, Object obj3, Object obj4, Object obj5, Object aobj[])
    {
        throw new UnsupportedOperationException();
    }

    public static ImmutableSortedSet of(Object aobj[])
    {
        throw new UnsupportedOperationException();
    }
}
