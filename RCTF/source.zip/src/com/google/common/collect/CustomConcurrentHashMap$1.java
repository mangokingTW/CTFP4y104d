// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            CustomConcurrentHashMap

static final class lueReference
    implements lueReference
{

    public void clear()
    {
    }

    public lueReference copyFor(ferenceEntry ferenceentry)
    {
        return this;
    }

    public Object get()
    {
        return null;
    }

    public boolean isComputingReference()
    {
        return false;
    }

    public void notifyValueReclaimed()
    {
    }

    public Object waitForValue()
    {
        return null;
    }

    lueReference()
    {
    }
}
