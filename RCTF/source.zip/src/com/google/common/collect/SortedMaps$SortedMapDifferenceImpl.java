// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;

import java.util.Map;
import java.util.SortedMap;

// Referenced classes of package com.google.common.collect:
//            SortedMapDifference, SortedMaps

static class  extends 
    implements SortedMapDifference
{

    public volatile Map entriesDiffering()
    {
        return entriesDiffering();
    }

    public SortedMap entriesDiffering()
    {
        return (SortedMap)super.ring();
    }

    public volatile Map entriesInCommon()
    {
        return entriesInCommon();
    }

    public SortedMap entriesInCommon()
    {
        return (SortedMap)super.mon();
    }

    public volatile Map entriesOnlyOnLeft()
    {
        return entriesOnlyOnLeft();
    }

    public SortedMap entriesOnlyOnLeft()
    {
        return (SortedMap)super.nLeft();
    }

    public volatile Map entriesOnlyOnRight()
    {
        return entriesOnlyOnRight();
    }

    public SortedMap entriesOnlyOnRight()
    {
        return (SortedMap)super.nRight();
    }

    (boolean flag, SortedMap sortedmap, SortedMap sortedmap1, SortedMap sortedmap2, SortedMap sortedmap3)
    {
        super(flag, sortedmap, sortedmap1, sortedmap2, sortedmap3);
    }
}
