// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            AbstractIndexedListIterator, ImmutableSet

class this._cls0 extends AbstractIndexedListIterator
{

    final urce this$0;

    protected Object get(int i)
    {
        return ansform(urce[i]);
    }

    (int i)
    {
        this$0 = this._cls0.this;
        super(i);
    }
}
