// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;

import java.util.Collection;
import java.util.List;

// Referenced classes of package com.google.common.collect:
//            ListMultimap, MapConstraints, MapConstraint

private static class t> extends t>
    implements ListMultimap
{

    public volatile Collection get(Object obj)
    {
        return get(obj);
    }

    public List get(Object obj)
    {
        return (List)super.get(obj);
    }

    public volatile Collection removeAll(Object obj)
    {
        return removeAll(obj);
    }

    public List removeAll(Object obj)
    {
        return (List)super.veAll(obj);
    }

    public volatile Collection replaceValues(Object obj, Iterable iterable)
    {
        return replaceValues(obj, iterable);
    }

    public List replaceValues(Object obj, Iterable iterable)
    {
        return (List)super.aceValues(obj, iterable);
    }

    (ListMultimap listmultimap, MapConstraint mapconstraint)
    {
        super(listmultimap, mapconstraint);
    }
}
