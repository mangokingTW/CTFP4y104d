// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            ImmutableMultimap, Serialization

static class 
{

    static final  MAP_FIELD_SETTER = Serialization.getFieldSetter(com/google/common/collect/ImmutableMultimap, "map");
    static final  SIZE_FIELD_SETTER = Serialization.getFieldSetter(com/google/common/collect/ImmutableMultimap, "size");


    ()
    {
    }
}
