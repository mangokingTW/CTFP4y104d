// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            AbstractIndexedListIterator, Lists

class nit> extends AbstractIndexedListIterator
{

    final get this$0;

    protected Character get(int i)
    {
        return Character.valueOf(cess._mth000(this._cls0.this).charAt(i));
    }

    protected volatile Object get(int i)
    {
        return get(i);
    }

    (int i, int j)
    {
        this$0 = this._cls0.this;
        super(i, j);
    }
}
