// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            CustomConcurrentHashMap

static final class nit> extends nit>
{

    nit> newEntry(CustomConcurrentHashMap customconcurrenthashmap, Object obj, int i, nit> nit>)
    {
        return new it>(customconcurrenthashmap, obj, i, nit>);
    }

    (String s, int i)
    {
        super(s, i, null);
    }
}
