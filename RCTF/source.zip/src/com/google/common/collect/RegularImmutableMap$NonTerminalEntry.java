// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            ImmutableEntry, RegularImmutableMap

private static final class next extends ImmutableEntry
    implements next
{

    final next next;

    public next next()
    {
        return next;
    }

    (Object obj, Object obj1,  )
    {
        super(obj, obj1);
        next = ;
    }
}
