// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;


// Referenced classes of package com.google.common.collect:
//            AbstractIterator

static class ate
{

    static final int $SwitchMap$com$google$common$collect$AbstractIterator$State[];

    static 
    {
        $SwitchMap$com$google$common$collect$AbstractIterator$State = new int[ate.values().length];
        try
        {
            $SwitchMap$com$google$common$collect$AbstractIterator$State[ate.DONE.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$com$google$common$collect$AbstractIterator$State[ate.READY.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
