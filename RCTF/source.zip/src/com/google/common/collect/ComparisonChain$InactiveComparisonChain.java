// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package com.google.common.collect;

import java.util.Comparator;

// Referenced classes of package com.google.common.collect:
//            ComparisonChain

private static final class result extends ComparisonChain
{

    final int result;

    public ComparisonChain compare(double d, double d1)
    {
        return this;
    }

    public ComparisonChain compare(float f, float f1)
    {
        return this;
    }

    public ComparisonChain compare(int i, int j)
    {
        return this;
    }

    public ComparisonChain compare(long l, long l1)
    {
        return this;
    }

    public ComparisonChain compare(Comparable comparable, Comparable comparable1)
    {
        return this;
    }

    public ComparisonChain compare(Object obj, Object obj1, Comparator comparator)
    {
        return this;
    }

    public ComparisonChain compare(boolean flag, boolean flag1)
    {
        return this;
    }

    public int result()
    {
        return result;
    }

    (int i)
    {
        super(null);
        result = i;
    }
}
